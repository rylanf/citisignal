export declare function getCookie(cookieName: string): string | null;
//# sourceMappingURL=cookies.d.ts.map