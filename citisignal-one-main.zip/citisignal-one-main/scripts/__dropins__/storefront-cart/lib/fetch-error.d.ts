/** Actions */
export declare const handleFetchError: (errors: Array<{
    message: string;
    extensions: {
        category: string;
    };
}>) => null;
//# sourceMappingURL=fetch-error.d.ts.map