export * from './MiniCart';
export { MiniCart as default } from './MiniCart';
//# sourceMappingURL=index.d.ts.map