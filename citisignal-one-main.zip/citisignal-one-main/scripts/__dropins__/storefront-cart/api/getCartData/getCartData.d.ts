import { CartModel } from '../../data/models';

export declare const getCartData: () => Promise<CartModel | null>;
//# sourceMappingURL=getCartData.d.ts.map