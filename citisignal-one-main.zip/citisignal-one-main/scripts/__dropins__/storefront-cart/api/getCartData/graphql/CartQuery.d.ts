export declare const GUEST_CART_QUERY: string;
export declare const CUSTOMER_CART_QUERY: string;
//# sourceMappingURL=CartQuery.d.ts.map