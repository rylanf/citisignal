export declare const GET_ESTIMATED_TOTALS_MUTATION: string;
//# sourceMappingURL=GetEstimatedTotalsMutation.d.ts.map