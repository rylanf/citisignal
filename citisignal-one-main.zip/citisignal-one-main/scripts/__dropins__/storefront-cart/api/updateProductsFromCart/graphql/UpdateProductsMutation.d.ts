export declare const UPDATE_PRODUCTS_FROM_CART_MUTATION: string;
//# sourceMappingURL=UpdateProductsMutation.d.ts.map