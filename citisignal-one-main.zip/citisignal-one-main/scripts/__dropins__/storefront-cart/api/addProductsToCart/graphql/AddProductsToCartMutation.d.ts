export declare const ADD_PRODUCTS_TO_CART_MUTATION: string;
//# sourceMappingURL=AddProductsToCartMutation.d.ts.map