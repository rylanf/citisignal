import { CartModel } from '../../data/models';

export declare const initializeCart: () => Promise<CartModel | null>;
//# sourceMappingURL=initializeCart.d.ts.map