export declare const MERGE_CARTS_MUTATION: string;
//# sourceMappingURL=MergeCartsMutation.d.ts.map