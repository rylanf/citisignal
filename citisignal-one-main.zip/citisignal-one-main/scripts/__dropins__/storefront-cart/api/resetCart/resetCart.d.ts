import { CartModel } from '../../data/models';

export declare const resetCart: () => Promise<CartModel | null>;
//# sourceMappingURL=resetCart.d.ts.map