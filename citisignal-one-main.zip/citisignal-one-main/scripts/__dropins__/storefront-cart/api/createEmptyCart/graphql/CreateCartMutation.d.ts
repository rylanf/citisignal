export declare const CREATE_EMPTY_CART_MUTATION = "\n    mutation CREATE_EMPTY_CART_MUTATION {\n        createEmptyCart\n    }\n";
//# sourceMappingURL=CreateCartMutation.d.ts.map