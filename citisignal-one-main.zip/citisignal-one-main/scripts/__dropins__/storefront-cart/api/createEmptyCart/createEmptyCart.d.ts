export declare const createEmptyCart: () => Promise<any>;
//# sourceMappingURL=createEmptyCart.d.ts.map