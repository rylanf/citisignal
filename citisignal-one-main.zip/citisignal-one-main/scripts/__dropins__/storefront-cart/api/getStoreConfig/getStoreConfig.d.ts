import { StoreConfigModel } from '../../data/models';

export declare const getStoreConfig: () => Promise<StoreConfigModel | null>;
//# sourceMappingURL=getStoreConfig.d.ts.map