export * from './getStoreConfig';
//# sourceMappingURL=index.d.ts.map