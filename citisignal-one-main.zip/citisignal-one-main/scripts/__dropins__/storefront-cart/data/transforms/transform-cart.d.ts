import { CartModel } from '../models';

export declare function transformCart(data: any): CartModel | null;
//# sourceMappingURL=transform-cart.d.ts.map