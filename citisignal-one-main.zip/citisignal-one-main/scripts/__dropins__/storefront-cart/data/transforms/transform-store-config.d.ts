import { StoreConfigModel } from '../models';

export declare function transformStoreConfig(data: any): StoreConfigModel | null;
//# sourceMappingURL=transform-store-config.d.ts.map