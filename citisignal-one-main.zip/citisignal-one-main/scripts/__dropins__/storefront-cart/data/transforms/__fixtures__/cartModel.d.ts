import { CartModel } from '../../models/cart-model';

export declare const cart: CartModel;
//# sourceMappingURL=cartModel.d.ts.map