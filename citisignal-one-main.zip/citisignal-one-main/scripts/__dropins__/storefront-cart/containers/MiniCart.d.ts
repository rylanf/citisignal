export * from './MiniCart/index'
import _default from './MiniCart/index'
export default _default
