import{Initializer as o}from"@dropins/tools/lib.js";const i=new o({init:async n=>{const e={authHeaderConfig:{header:"Authorization",tokenPrefix:"Bearer"}};i.config.setConfig({...e,...n})},listeners:()=>[]}),a=i.config;export{a as c,i};
//# sourceMappingURL=initialize.js.map
