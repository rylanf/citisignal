export declare const getPaymentMethods: (cartId: string) => Promise<{
    errors?: import('@adobe/fetch-graphql').FetchQueryError | undefined;
    data: any;
}>;
//# sourceMappingURL=getPaymentMethods.d.ts.map