export * from './fetch-graphql';
//# sourceMappingURL=index.d.ts.map