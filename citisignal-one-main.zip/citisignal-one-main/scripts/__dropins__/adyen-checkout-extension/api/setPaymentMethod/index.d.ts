export * from './setPaymentMethod';
//# sourceMappingURL=index.d.ts.map