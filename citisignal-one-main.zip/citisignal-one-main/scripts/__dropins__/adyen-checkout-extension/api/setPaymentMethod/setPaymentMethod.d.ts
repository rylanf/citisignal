export declare const handleNetworkError: (error: Error) => never;
/** end of duplicate code from checkout-domain-package */
export declare const setPaymentMethod: (cartId: string, type: string, additionalData: any) => Promise<void>;
//# sourceMappingURL=setPaymentMethod.d.ts.map