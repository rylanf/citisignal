export * from './getConfiguration';
//# sourceMappingURL=index.d.ts.map