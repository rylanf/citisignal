export declare const GET_TEST_CONFIGURATION = "\nquery GET_CONFIGURATION {\n    storeConfig {\n        adyen_client_key_test\n    }\n}\n";
export declare const GET_LIVE_CONFIGURATION = "\nquery GET_CONFIGURATION {\n    storeConfig {\n        adyen_client_key_live\n    }\n}\n";
//# sourceMappingURL=getConfiguration.graphql.d.ts.map