import { EnvironmentType } from '..';

export declare const getConfiguration: (environment: EnvironmentType) => Promise<{
    clientKey: any;
}>;
//# sourceMappingURL=getConfiguration.d.ts.map