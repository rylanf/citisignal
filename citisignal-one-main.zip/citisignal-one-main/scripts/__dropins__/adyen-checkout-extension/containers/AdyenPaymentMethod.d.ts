export * from './AdyenPaymentMethod/index'
import _default from './AdyenPaymentMethod/index'
export default _default
