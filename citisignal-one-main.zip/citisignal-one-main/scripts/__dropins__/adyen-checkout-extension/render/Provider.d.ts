import { FunctionComponent } from 'preact';

interface CartProviderProps {
    children?: any;
}
export declare const Provider: FunctionComponent<CartProviderProps>;
export declare const useLocale: () => "en_US";
export {};
//# sourceMappingURL=Provider.d.ts.map