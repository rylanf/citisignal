export * from './Heading';
export { Heading as default } from './Heading';
//# sourceMappingURL=index.d.ts.map