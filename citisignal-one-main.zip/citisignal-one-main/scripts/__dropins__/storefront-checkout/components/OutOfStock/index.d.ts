export * from './OutOfStock';
export { OutOfStock as default } from './OutOfStock';
//# sourceMappingURL=index.d.ts.map