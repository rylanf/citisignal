export { default as Card } from './Card.png';
//# sourceMappingURL=index.d.ts.map