export { default as Card } from './Card.svg';
//# sourceMappingURL=index.d.ts.map