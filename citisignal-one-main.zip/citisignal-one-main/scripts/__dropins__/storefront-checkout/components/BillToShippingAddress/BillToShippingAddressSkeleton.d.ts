import { FunctionComponent } from 'preact';

export declare const BillToShippingAddressSkeleton: FunctionComponent;
//# sourceMappingURL=BillToShippingAddressSkeleton.d.ts.map