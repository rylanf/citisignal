export declare const MULTILINE_SUFFIX = "-";
export declare const MULTILINE_CUSTOM_ATTR_SPLIT = "\n";
export declare const DEBOUNCE_TIME = 2000;
//# sourceMappingURL=constants.d.ts.map