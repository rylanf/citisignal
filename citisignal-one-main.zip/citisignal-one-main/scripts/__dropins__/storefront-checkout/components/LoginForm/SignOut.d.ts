import { FunctionComponent } from 'preact';

type SignOutProps = {
    onSignOutClick?: () => void;
};
export declare const SignOut: FunctionComponent<SignOutProps>;
export {};
//# sourceMappingURL=SignOut.d.ts.map