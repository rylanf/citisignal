import { FunctionComponent } from 'preact';

export declare const LoginFormSkeleton: FunctionComponent;
//# sourceMappingURL=LoginFormSkeleton.d.ts.map