import { FunctionComponent } from 'preact';

export declare const CartSummarySkeleton: FunctionComponent;
//# sourceMappingURL=CartSummarySkeleton.d.ts.map