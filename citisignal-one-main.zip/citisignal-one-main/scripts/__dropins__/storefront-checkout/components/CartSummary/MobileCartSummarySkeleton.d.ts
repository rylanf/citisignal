import { FunctionComponent } from 'preact';

export declare const MobileCartSummarySkeleton: FunctionComponent;
//# sourceMappingURL=MobileCartSummarySkeleton.d.ts.map