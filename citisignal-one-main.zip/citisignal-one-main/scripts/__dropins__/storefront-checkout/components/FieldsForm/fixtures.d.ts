import { AddressFormElement } from '../../data/models/address-form-fields';

declare const defaultFormElements: AddressFormElement[];
export { defaultFormElements };
//# sourceMappingURL=fixtures.d.ts.map