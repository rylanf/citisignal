import { FunctionComponent } from 'preact';

export declare const FieldsFormSkeleton: FunctionComponent;
//# sourceMappingURL=FieldsFormSkeleton.d.ts.map