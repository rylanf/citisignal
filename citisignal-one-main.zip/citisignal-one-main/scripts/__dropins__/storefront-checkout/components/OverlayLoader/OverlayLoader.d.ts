import { FunctionComponent } from 'preact';

export declare const OverlayLoader: FunctionComponent<{
    className?: string;
}>;
//# sourceMappingURL=OverlayLoader.d.ts.map