import { FunctionComponent } from 'preact';

export declare const ShippingMethodsSkeleton: FunctionComponent;
//# sourceMappingURL=ShippingMethodsSkeleton.d.ts.map