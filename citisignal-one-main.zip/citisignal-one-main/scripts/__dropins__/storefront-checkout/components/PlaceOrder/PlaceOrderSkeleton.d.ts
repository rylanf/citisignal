import { FunctionComponent } from 'preact';

export declare const PlaceOrderSkeleton: FunctionComponent;
//# sourceMappingURL=PlaceOrderSkeleton.d.ts.map