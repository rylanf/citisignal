import { FunctionComponent } from 'preact';

export declare const OrderSummarySkeleton: FunctionComponent;
//# sourceMappingURL=OrderSummarySkeleton.d.ts.map