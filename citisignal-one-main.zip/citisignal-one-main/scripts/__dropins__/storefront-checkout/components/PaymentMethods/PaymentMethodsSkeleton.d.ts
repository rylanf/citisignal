import { FunctionComponent } from 'preact';

export declare const PaymentMethodsSkeleton: FunctionComponent;
//# sourceMappingURL=PaymentMethodsSkeleton.d.ts.map