import{Initializer as t}from"@dropins/tools/lib.js";const i=new t({init:async n=>{const o={guestViewCookieExpirationDays:30,...n};i.config.setConfig(o)},listeners:()=>[]}),e=i.config;export{e as c,i};
//# sourceMappingURL=initialize.js.map
