var o=(r=>(r.InStock="IN_STOCK",r.OutOfStock="OUT_OF_STOCK",r))(o||{}),u=(r=>(r.Simple="SimpleProduct",r.Configurable="ConfigurableProduct",r.Downloadable="DownloadableProduct",r.GiftCard="GiftCardProduct",r.Virtual="VirtualProduct",r.Bundle="BundleProduct",r))(u||{});export{u as I,o as S};
//# sourceMappingURL=cart-item.js.map
