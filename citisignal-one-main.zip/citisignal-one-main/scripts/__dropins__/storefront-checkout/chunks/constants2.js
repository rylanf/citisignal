const o="login-form";export{o as L};
//# sourceMappingURL=constants2.js.map
