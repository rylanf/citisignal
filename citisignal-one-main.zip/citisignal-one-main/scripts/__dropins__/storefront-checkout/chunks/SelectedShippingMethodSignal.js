import{k as o}from"./getStoreConfig.js";const i=o(void 0);export{i as s};
//# sourceMappingURL=SelectedShippingMethodSignal.js.map
