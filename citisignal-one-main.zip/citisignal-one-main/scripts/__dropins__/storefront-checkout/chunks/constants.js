const s="shipping_address";export{s as S};
//# sourceMappingURL=constants.js.map
