import { FunctionComponent } from 'preact/compat';
import { AlertBannerProps } from '@dropins/tools/types/elsie/src/components';

export declare const MergedCartBanner: FunctionComponent<Partial<AlertBannerProps>>;
//# sourceMappingURL=MergedCartBanner.d.ts.map