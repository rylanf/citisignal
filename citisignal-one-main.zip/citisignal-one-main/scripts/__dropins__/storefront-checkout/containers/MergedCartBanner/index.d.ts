export * from './MergedCartBanner';
export { MergedCartBanner as default } from './MergedCartBanner';
//# sourceMappingURL=index.d.ts.map