export declare const SHIPPING_FORM_NAME = "shipping_address";
//# sourceMappingURL=constants.d.ts.map