export declare const BILLING_FORM_NAME = "billing_address";
//# sourceMappingURL=constants.d.ts.map