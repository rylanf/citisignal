import { Container } from '@dropins/tools/types/elsie/src/lib';
import { HTMLAttributes } from 'preact/compat';

export interface BillingFormProps extends HTMLAttributes<HTMLDivElement> {
}
export declare const BillingForm: Container<BillingFormProps>;
//# sourceMappingURL=BillingForm.d.ts.map