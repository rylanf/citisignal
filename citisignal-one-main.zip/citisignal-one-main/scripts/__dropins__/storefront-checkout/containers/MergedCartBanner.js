import{M as i,M}from"../chunks/MergedCartBanner.js";import"@dropins/tools/preact-compat.js";import"@dropins/tools/components.js";import"@dropins/tools/event-bus.js";import"@dropins/tools/preact-jsx-runtime.js";import"@dropins/tools/i18n.js";export{i as MergedCartBanner,M as default};
//# sourceMappingURL=MergedCartBanner.js.map
