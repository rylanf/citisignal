export declare const DEFAULT_VISIBLE_ITEMS = 5;
//# sourceMappingURL=constants.d.ts.map