export declare const ZERO_AMOUNT = 0;
//# sourceMappingURL=constants.d.ts.map