export declare const LOGIN_FORM_NAME = "login-form";
//# sourceMappingURL=constants.d.ts.map