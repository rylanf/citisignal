export declare const OUT_OF_STOCK = "OUT_OF_STOCK";
//# sourceMappingURL=constants.d.ts.map