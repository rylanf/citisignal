export declare const BILL_TO_SHIPPING_KEY = "is_bill_to_shipping_address";
//# sourceMappingURL=constants.d.ts.map