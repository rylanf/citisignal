export * from './PaymentMethods/index'
import _default from './PaymentMethods/index'
export default _default
