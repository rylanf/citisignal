export * from './ErrorBanner/index'
import _default from './ErrorBanner/index'
export default _default
