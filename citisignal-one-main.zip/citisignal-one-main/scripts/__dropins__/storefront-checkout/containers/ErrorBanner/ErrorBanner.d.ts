import { FunctionComponent } from 'preact/compat';
import { AlertBannerProps } from '@dropins/tools/types/elsie/src/components';

export declare const ErrorBanner: FunctionComponent<Partial<AlertBannerProps>>;
//# sourceMappingURL=ErrorBanner.d.ts.map