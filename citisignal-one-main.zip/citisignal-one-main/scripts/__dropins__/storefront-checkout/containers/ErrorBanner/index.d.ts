export * from './ErrorBanner';
export { ErrorBanner as default } from './ErrorBanner';
//# sourceMappingURL=index.d.ts.map