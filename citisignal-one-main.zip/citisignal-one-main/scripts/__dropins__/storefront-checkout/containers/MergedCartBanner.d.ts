export * from './MergedCartBanner/index'
import _default from './MergedCartBanner/index'
export default _default
