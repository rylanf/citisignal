export type Country = {
    value: string;
    label: string;
};
//# sourceMappingURL=country.d.ts.map