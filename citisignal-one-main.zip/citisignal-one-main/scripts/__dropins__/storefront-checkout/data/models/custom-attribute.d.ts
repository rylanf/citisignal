export type CustomAttribute = {
    code: string;
    value: string;
};
//# sourceMappingURL=custom-attribute.d.ts.map