export declare const setShippingAddressMutation: string;
//# sourceMappingURL=setShippingAddress.graphql.d.ts.map