export * from './setShippingAddress';
//# sourceMappingURL=index.d.ts.map