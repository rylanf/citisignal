export declare const setBillingAddressMutation: string;
//# sourceMappingURL=setBillingAddress.graphql.d.ts.map