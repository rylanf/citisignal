export declare const getCart: (cartId?: string) => Promise<import('../../data/models/cart').Cart | null | undefined>;
//# sourceMappingURL=getCart.d.ts.map