import { EmailAvailability } from '../../data/models/email-availability';

export declare const isEmailAvailable: (email: string) => Promise<EmailAvailability>;
//# sourceMappingURL=isEmailAvailable.d.ts.map