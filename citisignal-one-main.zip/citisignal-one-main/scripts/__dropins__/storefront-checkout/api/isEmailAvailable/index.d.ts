export * from './isEmailAvailable';
//# sourceMappingURL=index.d.ts.map