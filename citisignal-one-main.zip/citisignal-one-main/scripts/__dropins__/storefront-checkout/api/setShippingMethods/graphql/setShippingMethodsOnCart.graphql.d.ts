export declare const setShippingMethodsMutation: string;
//# sourceMappingURL=setShippingMethodsOnCart.graphql.d.ts.map