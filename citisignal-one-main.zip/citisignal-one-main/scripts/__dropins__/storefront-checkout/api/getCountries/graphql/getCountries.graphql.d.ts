export declare const getCountriesQuery = "\nquery getCountries {\n    countries {\n      two_letter_abbreviation\n      full_name_locale\n    }\n}";
//# sourceMappingURL=getCountries.graphql.d.ts.map