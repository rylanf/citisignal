import { Country as CountryModel } from '../../data/models/country';

export declare const getCountries: () => Promise<CountryModel[] | undefined>;
//# sourceMappingURL=getCountries.d.ts.map