import { Country as CountryModel } from '../../data/models/country';

export declare const europeanCountries: CountryModel[];
export declare const americanCountries: CountryModel[];
export declare const countries: CountryModel[];
//# sourceMappingURL=fixtures.d.ts.map