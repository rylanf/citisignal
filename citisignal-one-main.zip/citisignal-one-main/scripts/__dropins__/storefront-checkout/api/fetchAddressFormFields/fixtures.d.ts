import { AddressFormField } from '../../data/models/address-form-fields';

declare const defaultFormFields: AddressFormField[];
export { defaultFormFields };
//# sourceMappingURL=fixtures.d.ts.map