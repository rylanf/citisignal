import { AddressFormField } from '../../data/models';

export declare const fetchAddressFormFields: () => Promise<AddressFormField[]>;
//# sourceMappingURL=fetchAddressFormFields.d.ts.map