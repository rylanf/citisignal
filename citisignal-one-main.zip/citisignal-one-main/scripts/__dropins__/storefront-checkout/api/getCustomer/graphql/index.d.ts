export * from './getCustomer.graphql';
//# sourceMappingURL=index.d.ts.map