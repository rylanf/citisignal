import { Customer } from '../../data/models';

export declare const getCustomer: () => Promise<Customer | null | undefined>;
//# sourceMappingURL=getCustomer.d.ts.map