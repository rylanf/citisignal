export * from './getCustomer';
//# sourceMappingURL=index.d.ts.map