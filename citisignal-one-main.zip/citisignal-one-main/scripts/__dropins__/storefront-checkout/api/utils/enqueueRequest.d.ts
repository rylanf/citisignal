export declare function enqueueRequest<T>(requestFn: () => Promise<T>): Promise<T>;
//# sourceMappingURL=enqueueRequest.d.ts.map