export declare const placeOrder: (cartId: string) => Promise<void>;
//# sourceMappingURL=placeOrder.d.ts.map