export * from './placeOrder.graphql';
//# sourceMappingURL=index.d.ts.map