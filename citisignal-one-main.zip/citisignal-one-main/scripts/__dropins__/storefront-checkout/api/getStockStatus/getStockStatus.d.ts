import { ProductStockStatus } from '../../__generated__/types';

export declare const getStockStatus: (cartId?: string) => Promise<ProductStockStatus>;
//# sourceMappingURL=getStockStatus.d.ts.map