export * from './getRegions';
//# sourceMappingURL=index.d.ts.map