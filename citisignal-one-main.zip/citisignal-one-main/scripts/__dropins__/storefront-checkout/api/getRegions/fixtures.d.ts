import { Region as RegionModel } from '../../data/models/region';

export declare const americanRegions: RegionModel[];
export declare const frenchRegions: RegionModel[];
//# sourceMappingURL=fixtures.d.ts.map