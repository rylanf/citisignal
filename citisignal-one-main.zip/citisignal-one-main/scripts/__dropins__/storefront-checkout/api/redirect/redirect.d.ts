export declare const redirect: (url: string) => void;
//# sourceMappingURL=redirect.d.ts.map