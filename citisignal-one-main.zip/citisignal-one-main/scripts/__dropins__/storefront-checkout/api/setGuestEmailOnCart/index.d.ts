export * from './setGuestEmailOnCart';
//# sourceMappingURL=index.d.ts.map