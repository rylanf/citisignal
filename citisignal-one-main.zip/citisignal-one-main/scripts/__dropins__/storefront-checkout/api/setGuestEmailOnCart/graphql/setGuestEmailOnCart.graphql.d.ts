export declare const setGuestEmailMutation: string;
//# sourceMappingURL=setGuestEmailOnCart.graphql.d.ts.map