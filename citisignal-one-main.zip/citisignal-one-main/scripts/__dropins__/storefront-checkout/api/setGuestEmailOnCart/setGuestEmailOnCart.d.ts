export type SetGuestEmailOnCartInput = {
    cartId: string;
    email: string;
};
export declare const setGuestEmailOnCart: ({ cartId, email, }: SetGuestEmailOnCartInput) => Promise<import('../../data/models/cart').Cart | null | undefined>;
//# sourceMappingURL=setGuestEmailOnCart.d.ts.map