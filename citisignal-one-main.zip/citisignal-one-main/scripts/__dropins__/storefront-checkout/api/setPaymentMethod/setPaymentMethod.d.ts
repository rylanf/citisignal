export declare const setPaymentMethod: ({ cartId, paymentMethod, }: {
    cartId: string;
    paymentMethod: string;
}) => Promise<import('../../data/models/cart').Cart | null | undefined>;
//# sourceMappingURL=setPaymentMethod.d.ts.map