export declare const setPaymentMethodMutation: string;
//# sourceMappingURL=setPaymentMethod.graphql.d.ts.map