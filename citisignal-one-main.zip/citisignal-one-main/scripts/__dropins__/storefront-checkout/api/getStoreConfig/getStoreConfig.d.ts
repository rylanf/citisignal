import { StoreConfig } from '../../data/models';

export declare const getStoreConfig: () => Promise<StoreConfig>;
//# sourceMappingURL=getStoreConfig.d.ts.map